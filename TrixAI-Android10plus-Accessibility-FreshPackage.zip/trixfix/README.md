# Trix AI

Android 10+ accessibility build. Package ID: com.trixai.assistant
