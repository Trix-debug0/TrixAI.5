package com.trixai.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.telephony.PhoneNumberUtils
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private lateinit var prefs: SharedPreferences
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val speechRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        tts = TextToSpeech(this, this)
        prefs = getSharedPreferences("trix", MODE_PRIVATE)

        findViewById<Button>(R.id.micButton).setOnClickListener { listen() }
        findViewById<Button>(R.id.settingsButton).setOnClickListener { openSettings() }
        findViewById<Button>(R.id.geminiButton).setOnClickListener { configureGeminiKey() }
        findViewById<Button>(R.id.accessibilityButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.readScreenButton).setOnClickListener {
            val service = TrixAccessibilityService.instance
            if (service == null) {
                speak("Please enable Trix AI Accessibility Service first.")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                val text = service.speakCurrentScreen()
                status.text = if (text.isBlank()) "No readable text found" else "Reading screen"
            }
        }
        findViewById<Button>(R.id.overlayButton).setOnClickListener { openOverlaySettings() }

        requestMissingPermissions()
    }

    private fun requestMissingPermissions() {
        val wanted = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (android.os.Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = wanted.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }.toTypedArray()
        if (missing.isNotEmpty()) requestPermissions(missing, 2001)
    }

    private fun listen() {
        status.text = "Listening..."
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Trix AI")
        }
        try {
            startActivityForResult(intent, speechRequest)
        } catch (_: Exception) {
            fail("Speech recognition is unavailable on this device.")
        }
    }

    @Deprecated("Android activity result API retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != speechRequest) return
        val command = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.trim().orEmpty()
        if (resultCode == RESULT_OK && command.isNotEmpty()) handleCommand(command)
        else status.text = "Trix AI Ready"
    }

    private fun handleCommand(command: String) {
        status.text = "Thinking..."
        val lower = command.lowercase(Locale.ROOT).trim()

        when {
            lower.contains("battery") -> {
                val pct = getSystemService(BatteryManager::class.java)
                    .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                speak("Your battery is $pct percent.")
                ready()
            }
            lower.contains("flashlight") && (lower.contains("on") || lower.contains("turn on")) -> setFlashlight(true)
            lower.contains("flashlight") && (lower.contains("off") || lower.contains("turn off")) -> setFlashlight(false)
            lower.contains("volume") -> handleVolume(lower)
            lower == "open settings" || lower.contains("settings kholo") || lower.contains("open settings") -> {
                startActivity(Intent(Settings.ACTION_SETTINGS)); speak("Opening Settings."); ready()
            }
            lower.contains("accessibility settings") -> {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); speak("Opening Accessibility Settings."); ready()
            }
            lower.contains("overlay") -> openOverlaySettings()
            lower.startsWith("call ") || lower.contains("call ") || lower.contains("phone karo") || lower.contains("phone karo") -> askGemini(command)
            else -> askGemini(command)
        }
    }

    private fun askGemini(command: String) {
        val key = prefs.getString("gemini_api_key", "").orEmpty()
        if (key.isBlank()) {
            status.text = "Gemini key required"
            speak("Gemini is not configured. Open Configure Gemini API Key in Trix AI settings.")
            return
        }
        scope.launch {
            val result = kotlinx.coroutines.withContext(Dispatchers.IO) { GeminiClient(key).understand(command) }
            if (result.error != null) { fail(result.error); return@launch }
            val j = result.json ?: run { fail("I couldn't understand the command."); return@launch }
            val intent = j.optString("intent", "UNKNOWN")
            val reply = j.optString("reply").ifBlank { "I understood that as $intent." }

            if (j.optBoolean("needsConfirmation", false)) {
                confirmAndExecute(intent, j, reply)
            } else {
                executeIntent(intent, j, reply)
            }
        }
    }

    private fun confirmAndExecute(intent: String, data: org.json.JSONObject, reply: String) {
        val details = when (intent) {
            "SEND_WHATSAPP", "SEND_SMS" -> "${data.optString("contact").ifBlank { "the recipient" }}: ${data.optString("message")}"
            "CALL_NUMBER" -> data.optString("phone")
            else -> reply
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Confirm action")
            .setMessage(details)
            .setNegativeButton("Cancel") { _, _ -> speak("Cancelled."); ready() }
            .setPositiveButton("Confirm") { _, _ -> executeIntent(intent, data, reply) }
            .show()
        speak("Please confirm. $details")
    }

    private fun executeIntent(intent: String, data: org.json.JSONObject, reply: String) {
        when (intent) {
            "OPEN_APP" -> openRequestedApp(data.optString("app"), reply)
            "SEARCH_YOUTUBE" -> openYouTubeSearch(data.optString("query"), reply)
            "OPEN_SETTINGS" -> { startActivity(Intent(Settings.ACTION_SETTINGS)); speak(reply) }
            "CALL_NUMBER" -> callNumber(data.optString("phone"))
            "CALL_CONTACT" -> lookupAndCall(data.optString("contact"))
            "SEND_SMS" -> sendSms(data.optString("phone"), data.optString("message"))
            "SEND_WHATSAPP" -> sendWhatsApp(data.optString("phone"), data.optString("message"))
            "SEARCH_WEB" -> searchWeb(data.optString("query"))
            "GET_BATTERY" -> handleCommand("battery")
            else -> speak(reply)
        }
        ready()
    }

    private fun openRequestedApp(app: String, reply: String) {
        val wanted = app.trim().lowercase(Locale.ROOT)
        val packages = mapOf(
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "chrome" to "com.android.chrome",
            "instagram" to "com.instagram.android",
            "google maps" to "com.google.android.apps.maps",
            "maps" to "com.google.android.apps.maps"
        )
        val pkg = packages[wanted]
        if (pkg == null) { speak("I don't have a supported app mapping for $app yet."); return }
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) { startActivity(launch); speak(reply.ifBlank { "Opening $app." }) }
        else speak("$app is not installed.")
    }

    private fun openYouTubeSearch(query: String, reply: String) {
        val uri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)); speak(reply.ifBlank { "Searching YouTube for $query." }) }
        catch (_: Exception) { speak("I couldn't open YouTube.") }
    }

    private fun callNumber(phone: String) {
        val number = phone.trim()
        if (!PhoneNumberUtils.isGlobalPhoneNumber(number)) { speak("That phone number doesn't look valid."); return }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 3001); speak("Phone permission is required to place calls."); return
        }
        try { startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}"))); speak("Calling $number.") }
        catch (_: Exception) { speak("I couldn't place the call.") }
    }

    private fun lookupAndCall(contact: String) {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE), 3002)
            speak("Contacts permission is required to call a saved contact.")
            return
        }
        val projection = arrayOf(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER)
        val uri = android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        var number: String? = null
        contentResolver.query(uri, projection, "${android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$contact%"), null)?.use { c ->
            if (c.moveToFirst()) number = c.getString(0)
        }
        if (number == null) speak("I couldn't find $contact in your contacts.") else callNumber(number!!)
    }

    private fun sendSms(phone: String, message: String) {
        if (phone.isBlank() || message.isBlank()) { speak("I need a phone number and message."); return }
        try {
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(phone)}")).apply { putExtra("sms_body", message) }
            startActivity(i); speak("Opening the SMS composer for $phone.")
        } catch (_: Exception) { speak("I couldn't open the SMS composer.") }
    }

    private fun sendWhatsApp(phone: String, message: String) {
        try {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                setPackage("com.whatsapp")
                putExtra(Intent.EXTRA_TEXT, message)
            }
            startActivity(i)
            speak("Opening WhatsApp with your message ready. Tap Send if needed.")
        } catch (_: Exception) { speak("I couldn't open WhatsApp. Make sure it is installed.") }
    }

    private fun searchWeb(query: String) {
        if (query.isBlank()) { speak("What would you like me to search for?"); return }
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}"))); speak("Searching the web.") }
        catch (_: Exception) { speak("I couldn't open web search.") }
    }

    private fun setFlashlight(on: Boolean) {
        val camera = getSystemService(android.hardware.camera2.CameraManager::class.java)
        try {
            val id = camera.cameraIdList.firstOrNull { camera.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { speak("This device does not have a supported flashlight."); return }
            camera.setTorchMode(id, on); speak(if (on) "Flashlight on." else "Flashlight off.")
        } catch (_: Exception) { speak("I couldn't change the flashlight.") }
        ready()
    }

    private fun handleVolume(lower: String) {
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        when {
            lower.contains("up") || lower.contains("increase") || lower.contains("loud") -> audio.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_PLAY_SOUND)
            lower.contains("down") || lower.contains("decrease") || lower.contains("low") -> audio.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_PLAY_SOUND)
            else -> { speak("You can say volume up or volume down."); return }
        }
        speak("Volume changed."); ready()
    }

    private fun configureGeminiKey() {
        val input = EditText(this).apply {
            hint = "Paste Gemini API key"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("gemini_api_key", ""))
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Gemini API Key")
            .setMessage("For this prototype the key is stored locally. Do not share it.")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("gemini_api_key", input.text.toString().trim()).apply()
                Toast.makeText(this, "Gemini key saved", Toast.LENGTH_SHORT).show()
                speak("Gemini API key saved.")
            }.show()
    }

    private fun openOverlaySettings() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else speak("Overlay settings are not available on this Android version.")
        ready()
    }

    private fun openSettings() { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    private fun ready() { status.text = "Trix AI Ready" }
    private fun speak(text: String) { if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "trix") }
    private fun fail(text: String) { status.text = "Error"; speak(text) }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
            tts.setSpeechRate(0.95f)
        }
    }

    override fun onDestroy() {
        scope.coroutineContext.cancel()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
