package com.trixai.assistant

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Small REST client for Gemini. The key is supplied at runtime and is not hard-coded. */
class GeminiClient(private val apiKey: String) {
    companion object {
        private const val TAG = "TrixGemini"
        private const val MODEL = "gemini-3.8-flash"
        private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"
    }

    suspend fun understand(command: String): GeminiResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext GeminiResult.error("Gemini API key is not configured.")
        try {
            val system = """
You are Trix AI, a voice-first Android accessibility assistant for blind and visually impaired users.
The app UI is English-only. Understand English, Hindi, Hinglish and Urdu. Reply naturally in the user's language.
Return ONLY valid JSON matching this schema:
{"intent":"OPEN_APP|CALL_CONTACT|CALL_NUMBER|SEND_WHATSAPP|SEND_SMS|READ_SCREEN|READ_NOTIFICATION|SEARCH_YOUTUBE|SEARCH_WEB|PLAY_MEDIA|SET_ALARM|SET_TIMER|SET_REMINDER|FLASHLIGHT|VOLUME|GET_BATTERY|OPEN_SETTINGS|NAVIGATE|CAMERA_DESCRIPTION|OCR|GENERAL_AI|UNKNOWN","app":"","contact":"","phone":"","message":"","query":"","time":"","location":"","reply":"","needsConfirmation":false}
Set needsConfirmation=true for sending messages, calling unknown numbers, deleting data, sharing location, emergency actions, or other sensitive actions.
Keep reply concise and suitable for speech.
""".trimIndent()

            val body = JSONObject().apply {
                put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                put("contents", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", command)))
                }))
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.1)
                    put("responseMimeType", "application/json")
                })
            }

            val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 30000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-goog-api-key", apiKey)
            }

            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            conn.disconnect()

            if (code !in 200..299) {
                Log.e(TAG, "Gemini HTTP $code: $response")
                return@withContext GeminiResult.error("Gemini request failed. Check the API key and internet connection.")
            }

            val root = JSONObject(response)
            val text = root.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text")
                .orEmpty()
                .trim()
                .removePrefix("```json")
                .removeSuffix("```")
                .trim()

            if (text.isBlank()) return@withContext GeminiResult.error("Gemini returned an empty response.")
            GeminiResult.success(JSONObject(text))
        } catch (e: Exception) {
            Log.e(TAG, "Gemini error", e)
            GeminiResult.error("I couldn't connect to Gemini. Please check your internet connection and API key.")
        }
    }
}

data class GeminiResult(val json: JSONObject?, val error: String? = null) {
    companion object {
        fun success(json: JSONObject) = GeminiResult(json)
        fun error(message: String) = GeminiResult(null, message)
    }
}
